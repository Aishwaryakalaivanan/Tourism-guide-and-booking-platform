import pandas as pd

df = pd.read_csv("flipkart_com-ecommerce_sample.csv")
df = df[['uniq_id','product_name','retail_price']]
df = df[df['retail_price'] > 5000].head(600)  # filter
df['min_cibil'] = 600
df['max_cibil'] = 900
df['tenure_months'] = 12
df['interest_rate'] = 12.0

df.to_csv("emi_products_600.csv", index=False)
